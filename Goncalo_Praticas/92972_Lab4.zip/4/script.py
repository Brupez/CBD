from neo4j import GraphDatabase
from datetime import datetime
import json
import sys

# Generic class for database connection
# From: https://neo4j.com/developer/python/#python-driver
class Neo4JDatabase:

    def __init__(self, uri, user, password):
        self.driver = GraphDatabase.driver(uri, auth=(user, password))

    def close(self):
        self.driver.close()

    def write(self, func, message):
        with self.driver.session() as session:
            return session.write_transaction(func, message)
    
    def read(self, func, query):
        with self.driver.session() as session:
            return session.read_transaction(func, query)
        
# Custom method to handle the vaccionation tweets data
# ---
# Entities to create (Using <DataType:ColumnOnLine>)
# Person {
#   username:<String:1>, 
#   bio:<String:3>, 
#   created:<Date:4>, 
#   followers:<Integer:5>, 
#   friends:<Integer:6>, 
#   favorites:<Integer:7>, 
#   verified:<Bool:8>
# }
# Tweet {
#   id:<Integer:0>, 
#   date:<Date:9>, 
#   text:<String:10>, 
#   hashtags:<List<String>:11>, 
#   source:<String:12>, 
#   retweets:<Integer:13>, 
#   favorites:<Integer:14>, 
#   is_retweet:<Bool:15>
# }
# Location {
#   name:<String:2>
# }
# ---
# Relations
# (t:Tweet)-[:USER_LOCATION]->(l:Location)
# (t:Tweet)-[:AUTHOR]->(u:User) "
def writeTweets(tx, line):
    print()
    location = "Somewhere"
    if line[2]:
        location=line[2].strip()
    hashtags = []
    if line[11]:
        hashtags = json.loads(line[11].replace("'", '"'))
    result = tx.run(
        # Create nodes
        "MERGE (location:Location {name:$location}) "
        "MERGE (user:User {username:$username}) "
        "SET user.bio=$bio "
        ",user.created=$created "
        ",user.followers=$followers "
        ",user.friends=$friends "
        ",user.favorites=$favorites "
        ",user.verified=$verified "
        "MERGE (tweet:Tweet {tid:$tid}) "
        "SET tweet.date=$tdate "
        ",tweet.text=$ttext "
        ",tweet.source=$tsource "
        ",tweet.retweets=$tretweets "
        ",tweet.favorites=$tfavorites "
        ",tweet.is_retweet=$tis_retweet "
        ",tweet.hashtags=$thashtags "
        # Create relations
        "MERGE (tweet)-[:USER_LOCATION]->(location) "
        "MERGE (tweet)-[:AUTHOR]->(user) "
        "RETURN location, user, tweet", 
        # Location
        location=location,
        # User
        username=line[1],
        bio=line[3],
        created=datetime.strptime(line[4].strip(), "%Y-%m-%d %H:%M:%S"),
        followers=int(line[5]),
        friends=int(line[6]),
        favorites=int(line[7]),
        verified=True if line[8].strip()=="True" else False,
        # Tweet
        tid=float(line[0].replace(",", ".")),
        tdate=datetime.strptime(line[9].strip(), "%Y-%m-%d %H:%M:%S"),
        ttext=line[10].strip(),
        tsource=line[12],
        tretweets=int(line[13]),
        tfavorites=int(line[14]),
        tis_retweet=True if line[15].strip()=="True" else False,
        thashtags=hashtags
    )
    return [r for r in result.single()]

def query(tx, query):
    return tx.run(query)

# Queries
queries = [
    "MATCH (t:Tweet)-[:USER_LOCATION]->(l:Location {name:\"England\"}) MATCH (u:User)<-[:AUTHOR]-(t) RETURN u",
]

# main()
counter = 0
if __name__ == "__main__":
    # Connect to database
    db = Neo4JDatabase("bolt://localhost:7687", "neo4j", "tweets")

    # Populate database when -populate is given as argument
    if len(sys.argv)>1 and sys.argv[1]=="-populate":
        # Read file
        f = open("vaccination_tweets.tsv")
        # Ignore headers line
        f.readline()
        # and create nodes and relations foreach line
        for line in f:
            line = line.strip().split("\t")
            # Only consider lines with 16 cols
            # Preventing problems with tweets wich content has \n characters
            if len(line)==16:
                write = db.write(writeTweets, line)
                for w in write:
                    print(w)
                counter += 1
        print("\nLines written:", counter)

    # Queries
    # Not working :/
    print("\n\nQueries")
    for q in queries:
        print()
        print(q)
        results = db.read(query, q)
        print(results)
        print([r for r in results])
        for r in results:
            print("result:", r)

    # Close connection to db
    db.close()
