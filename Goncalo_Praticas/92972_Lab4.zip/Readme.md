#  CBD | Prática 4 | Neo4j

Gonçalo Matos, 92972



Esta é a base de dados orientada a grafos mais utilizada atualmente, destacando-se pelo facto de ser desenvolvida em código aberto, ter facilidade de escalabilidade, alta disponibilidade, tolerância a falhas, transações ACID. É implementada em Java e foi lançada em 2007 pela Neo Technology. Utiliza a linguagem de *queries* **Cypher**.

As suas principais características são:

- Como é característica das bases de dados NoSQL, o seu **modelo de dados** é bastante flexível:
- Implementa as propriedades **ACID** (Atomicidade, Consistência, Isolamento e Durabilidade);
- Facilidade de **escalabilidade** e **replicação**;
- Linguagem de ***queries* simples** e poderosa;
- Oferece uma **aplicação *web* incorporada**, que permite criar e manipular grafos;
- Existem ***drivers*** que permitem a sua manipulação através da maioria das linguagens de programação;
- Suporta **indexação** com base no Apache Lucene.

> Documentação [aqui](https://neo4j.com/docs/getting-started/current/)



## Modelo de dados

Cada grafo é composto por um ou mais nós relacionados (ou não) entre si. 

Cada **nó** tem uma estrutura dinâmica, mas que apresenta sempre um <u>ID único</u>, um <u>conjunto de etiquetas</u> que o categorizam e um <u>conjunto de propriedades</u>, que armazenam informação adicional.

Os **relacionamentos** (arestas) apresentam também um <u>ID único</u>, uma <u>direção</u>, um <u>nó de partida</u> e um <u>nó de chegada</u>, um <u>tipo único</u> e um <u>conjunto de propriedades</u>.



Em ambos os elementos as propriedades são um conjunto de pares <u>chave/valor</u>, onde a chave é uma *String* e o valor um tipo primitivo.

| Tipos de dados primitivos | Valor                                  |
| ------------------------- | -------------------------------------- |
| boolean                   | `true` ou `false`                      |
| byte, short, int, long    | Inteiros (1B, 2B, 4B, 8B)              |
| float, double             | Números com vírgula flutuante (4B, 8B) |
| char                      | Um carácter Unicode                    |
| String                    | Sequência de caracteres Unicode        |



## Cypher

> [Documentação](https://neo4j.com/docs/cypher-manual/current/)

Esta é a linguagem de *queries* utilizada no Neo4j e caracteriza-se por ser declarativa, altamente expressiva e eficiente.

> É inspirada em SQL (*query clauses*) e SPARQL (*pattern matching*)



### Nós

Os **nós** são representados entre <u>parêntesis curvos</u>: ().

```cypher
'(' varname? label* properties* ')';

// Sintaxe
varname = NAME
label = ':' NAME
properties = '{' (NAME ':' (PRIMITIVETYPE) )+ '}'

// Léxico
NAME = [a-zA-Z]+;
           
// Exemplo: (goncaloNode:PERSON {name: "Gonçalo", age: 20})
```

Se o `varname` for definido, o nó fica atribuído a essa variável e esta pode ser utilizada para se referir ao nó.



### Relacionamentos

As relações entre os nós são representadas entre <u>parêntesis retos</u>: [].

```cypher
node TOKEN [relation properties*] TOKEN node

// Sintaxe
relation (ver label nos nós)
properties (ver properties dos nós)

// Léxico
TOKEN = (-|->|<-)
         
// Exemplo: (goncaloNode)-[:TRABALHA_EM]->(uaNode)
// Para pesquisar por relações sem ter em conta a direção pode usar-se (n1)-[]-(n2)
```

Como não é controlada, deve ser tida em atenção a definição das etiquetas das relações, de forma a não ser perdida consistência.

> A relação TRABALHA_EM pode ser definida também por uma etiqueta como FUNCIONÁRIO_DE. Apesar de significarem praticamente o mesmo, identificar funcionários coma as duas etiquetas vai tornar a base de dados pouco consistente.



### Caminhos

Um caminho é um conjunto de nós ligados por relações. Não são criados diretamente, mas estão implícitos nas relações entre os nós e podem ser utilizados na manipulação dos dados.

```cypher
// Exemplo: path=((goncaloNode)-[:TRABALHA_EM]->(uaNode))
```



### Operações CRUD



#### Create

```cypher
CREATE node (',' node)*
```

```cypher
CREATE relation (',' relation)*
```



Para <u>criar apenas se não existir</u>, pode ser utilizado o `MERGE` com o atributo que identifica unicamente o nó. Caso ele exista, é associado à variável, caso contrário, é criado e também associado à variável.

```cypher
MERGE (p:Person {id:1234})
SET p.name="Name Surname";
```

Para definir/atualizar atributos adicionais, pode ser conjugado com o `SET`, como demonstrado acima.



#### Read

A seleção é feita com recurso à operação `MATCH`.

```cypher
MATCH query
[WITH operation AS varname, ...]
[WHERE condition]
RETURN returnVal

query = (node | relation)
// Use (n) to match all nodes
               
whereClause (semelhante à sintaxe SQL)
                           
propertySet = (node.property '=' primitiveType)+
                           
returnVal = (node | nodeProperty)
nodeProperty = node.property [AS NAME]
property = NAME 
```



##### Where



Esta cláusula permite adicionar restrições à pesquisa.

> Operadores de comparação
>
> | Operador             | Significado            |
> | -------------------- | ---------------------- |
> | =                    | Igualdade              |
> | <>                   | Diferença              |
> | <, >, <=, >=         | Maior/menor (ou igual) |
> | IS NULL, IS NOT NULL | Nulidade               |
>
> Operadores para análise de strings
>
> ```cypher
> [NOT] n.label [STARTS WITH | ENDS WITH | CONTAINS] 'String'
> ```

```cypher
MATCH query
WHERE whereClause [[AND | OR | XOR | NOT] whereClause ',']
RETURN returnVal
    
// MATCH (movie:MOVIE) WHERE movie.title="Titanic" RETURN movie.title AS title
// Same as:
// MATCH (movie:MOVIE {name:"Titanic"}) RETURN movie.title AS title
```



##### With

O WITH permite que partes do query sejam agregados, permitindo a sua utilização como ponto de partida para a continuação do query.

É importante perceber que o WITH <u>afeta o scope das variáveis</u>, sendo que as variáveis não incluídas nesta cláusula deixam de poder ser referenciadas no resto do query.



##### Ordenação

O resultado de um *query* pode ser manipulado com recurso às cláusulas de ordenação.

A `DISTINCT` ignora resultados duplicados, a `ORDER BY` define a ordem pela qual estes são apresentados.

A `LIMIT` retorna um *subset* dos resultados, a começar pelo primeiro.

O `SKIP` ignora as primeiras n linhas dos resultados, retornando todos a partir daí.

```cypher
MATCH query
RETURN [DISTINCT] returnVal
[ORDER BY node.property [DESC]]
[LIMIT INTEGER]
[SKIP INTEGER]
  
// MATCH (actor:PERSON)-[:ACTED_IN]->() RETURN DISTINCT actor ORDER BY actor.born
```



##### Relações de profundidade variável

É possível pesquisar relações não diretas entre nós, ou seja, caminhos de dimensão variável. Para tal, devemos de adaptar a sintaxe dos *queries*. São definidos abaixo alguns exemplos.

```cypher
// Qualquer profundidade
(a)-[*]->(b)
          
// Profundidade n
(a)-[*n]->(b)
          
// Profundidade entre 1 e 4
(a)-[*1..4]->(b)
              
// Tipo KNOWS e profundidade 3
(a)-[:KNOWS*3]->(b)
                 
// Tipo KNOWS oy LIKES e profundidade mínima de 2
(a)-[:KNOWS|:LIKES*2..]->(b)
```



##### Caminho mais curto

Para obter o caminho mais curto entre dois nós recorre-se ao `shortestPath()`.

```cypher
MATCH (a), (b) MATCH p=shortestPath((a)-[*]-(b)) RETURN p;
```



##### Agregação

A agregação é declarada na cláusula `RETURN` e pode fazer uso de uma das várias funções disponíveis.

| Função              | Propósito                        |
| :------------------ | -------------------------------- |
| `count(x)`          | Conta o número de ocorrências.   |
| `min(x)` / `max(x)` | Retorna o valor mínimo e máximo. |
| `avg(x)`            | Calcula a média dos valores.     |
| `sum(x)`            | Calcula a soma dos valores.      |
| `collect(x)`        | Lista os elementos numa coleção. |

```cypher
MATCH (person:Person) RETURN avg(person.age)
```



#### Update

As atualizações de dados são feitas com recurso à cláusula `SET`.

```cypher
MATCH query
SET query
RETURN returnVal
// MATCH (p:Person{name:"Trump"}) SET p.fired=True;
```

> Não permite a definição de tipos de relações!



#### Delete

Para eliminar um nó temos de identificar o espaço de nós a considerar antes da eliminação em si.

```cypher
MATCH query
[DETACH] DELETE node

// MATCH (p:Person{name:"Trump"}) DETACH DELETE p
// Same as:
// MATCH (p:Person{name:"Trump"}) OPTIONAL MATCH (p)-[r]-() DELETE p,r
```

> Não é possível remover nós que tenham a si associadas relações! As relações devem ser eliminadas primeiro, ou ser utilizada a cláusula `DETACH`.
>
> O segundo exemplo apresenta uma alternativa, que é a de selecionar o nó e todas as relações que cada um destes tem a si associado, eliminando os dois em simultâneo.

É ainda possível eliminar propriedades ou etiquetas de um nó ou relação, com recurso à cláusula `REMOVE`.

```cypher
MATCH query
REMOVE (node.propertyName | node:labelName)
RETURN returnVal 
```



### Funções

#### Nós

Há ainda algumas funções que podem ser utilizadas para analisar as propriedades dos nós.

| Função    | Propósito                         |
| --------- | --------------------------------- |
| labels(n) | Retorna lista com tipos do nó     |
| keys(n)   | Retorna lista com atributos do nó |

```cypher
match (n)
return labels(n) as labels, keys(n) as keys, count(*) as total
order by total desc;
```

#### Relações

| Função  | Propósito                |
| ------- | ------------------------ |
| type(r) | Retorna tipo da relação. |

```cypher
match (m)-[r]->(n)
return labels(m), type(r), labels(n), count(*) as total
order by total desc;
```

#### Caminhos

| Função    | Propósito               |
| --------- | ----------------------- |
| length(p) | Comprimento do caminho. |

#### Manipulação de dados

| Função       | Propósito                       |
| ------------ | ------------------------------- |
| round(n)     | Arredonda um número às unidades |
| toInteger(n) | Converte String para Integer    |

Estas podem ser utilizadas para manipulações adicionais.

```cypher
// Arrendondar um Float a 2 casas decimais
// Temos de multiplicar por 100, arrendar às unidades e voltar a dividir por 100
round(n * 100) / 100
```





### Índices

Para tornar a pesquisa mais eficiente, o Neo4j permite também a criação de índices sobre as relações.

```cypher
CREATE [BTREE] INDEX [index_name] [IF NOT EXISTS]
FOR (node:LabelName)
ON (node.propertyName)
[OPTIONS "{" option: value[,...] "}"]
          
// CREATE INDEX ON :Person(name)
```

Uma vez criados, podem ser eliminados.

```cypher
DROP INDEX index_name

DROP INDEX ON (node.propertyName)
```



## Instalação e utilização

Descarregar aplicação em https://neo4j.com/download/, que será um ficheiro com extensão `.AppImage`.

Uma vez descarregado, basta abrir o terminal, dar autorização para execução e executar a aplicação.

```bash
# Substituir (...) pelo nome do ficheiro
$ chmod +x (...).AppImage
$ ./(...).AppImage
```

> Para cada base de dados o utilizador será `neo4j` e a palavra-passe a definida na sua criação.
>
> Caso palavra-passe seja esquecida, recorrer ao seahorse.



## Importação em massa de dados

> [Doc](https://neo4j.com/docs/cypher-manual/current/functions/load-csv/)

O Neo4j permite a importação de dados em massa a partir de ficheiros `.csv`. A primeira linha deve definir os títulos das várias colunas cujos valores são definidos nas linhas seguintes.

A importação é feita com recurso à cláusula `LOAD CSV`. Para cada linha estão acessíveis as propriedades definidas no cabeçalho.

```cypher
LOAD CSV WITH HEADERS
FROM filelocation
AS line
CREATE (movie:Movie {id:line.id, title:line.title})
```

Para correr este comando na interface web é necessário que o ficheiro a importar esteja na pasta /import da base de dados. Mais info [aqui](https://neo4j.com/docs/operations-manual/current/configuration/file-locations/).



## Drivers

Python 

https://neo4j.com/docs/api/python-driver/current/