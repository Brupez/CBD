export JAVA_HOME=/usr/lib/jvm/java-8-openjdk
export JRE_HOME=/usr/lib/jvm/java-8-openjdk/jre
export PATH=$PATH:$JAVA_HOME/bin:$JRE_HOME/bin
